import { Col, Dropdown, Layout, Menu, Row } from "antd";
import React, { Suspense, useEffect, useState } from "react";
import { Link, Redirect, Route, Switch, useLocation } from "react-router-dom";
import { LockOutlined } from "@ant-design/icons";
// import "antd/dist/antd.css";
import "antd/dist/antd.min.css";
import "./AppLayout.css";
import { INFO_LOCALSTORAGE } from "../../shared/constants/constant";
import RouterConfig from "../../routers/RouterConfig";
import images from "./../../../res/images";

const { Header, Sider, Content, Footer } = Layout;

function AppLayout() {
  const [collapsed, setCollapsed] = useState(false);
  // const [fullName, setFullName] = useState("");
  const [activeMenu, setActiveMenu] = useState(
    window.location.href.split("/")[3]
  );

  const currentLocation = window.location.href.split("/")[3];

  useEffect(() => {
    // const obj = localStorage.getItem(INFO_LOCALSTORAGE.USER_LOGGED) || "";
    // let parseObj = JSON.parse(obj);
    // setFullName(parseObj.username);
  }, []);

  const toggle = () => {
    setCollapsed(!collapsed);
  };

  // const logout = () => {
  //   localStorage.clear();
  //   window.location.href = "/login";
  // };

  const menu = (
    <Menu>
      <Menu.Item
        icon={<LockOutlined />}
      // onClick={logout}
      >
        <a>Đăng xuất</a>
      </Menu.Item>
    </Menu>
  );

  return (
    <>
      <Layout>
        <Sider
          trigger={null}
          collapsible
          collapsed={collapsed}
          className="sidebar"
        >
          <div className="wrapper_logo">
            <div className="logo" />
          </div>
          <Menu mode="inline" defaultSelectedKeys={[activeMenu]}>
            <Menu.Item
              key="portal"
              icon={<img src={images.ic_document} className="ic_item_menu" />}
              className={
                currentLocation == "portal" || currentLocation == ""
                  ? "select_itemenu"
                  : ""
              }
            >
              <Link to="/portal">Quản lý portal</Link>
            </Menu.Item>
          </Menu>
        </Sider>

        <Layout>
          <Layout className="site-layout layout_content">
            <Header className="site-layout-background headerBar">
              <Row gutter={[24, 24]} className="full_height">
                <Col xs={24} xl={24} className="h_left">
                  <Row gutter={[24, 6]} className="">
                    <Col xs={24} xl={24}>
                      <span className="title_header">
                        Hệ thống công nghệ thông tin VTS
                      </span>
                    </Col>
                  </Row>
                </Col>
                {/* <Col xs={12} xl={12} className="h_right">
                <Row gutter={[24, 6]} className="">
                    <Col xs={2} xl={2}>
            
                    </Col>
                  </Row>
                </Col> */}
              </Row>
            </Header>
            <Content
              className="site-layout-background"
              style={{
                margin: "24px 16px",
                padding: 24,
                minHeight: 280
              }}
            >
              <Suspense fallback={<h1>Loading...</h1>}>
                <Switch>
                  {RouterConfig.map((route: any, i: any) => {
                    return (
                      <Route
                        key={i}
                        exact
                        path={route.path}
                        component={route.component}
                      />
                    );
                  })}
                </Switch>
              </Suspense>
            </Content>
          </Layout>
        </Layout>
      </Layout>
    </>
  );
}

export default AppLayout;
