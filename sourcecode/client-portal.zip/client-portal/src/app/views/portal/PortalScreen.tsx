import React from "react";
import {
  ERROR_CONNECT,
  INFO_LOCALSTORAGE,
  RESPONSE_CODE,
  ERROR_CODE,
  HEIGHT_TBODY,
  PAGE_SETTING,
  VALUE_STATUS,
} from "../../shared/constants/constant";
import {
  Col,
  message,
  Row,
  Spin,
  Button,
} from "antd";
import "./PortalScreen.css";
import images from "./../../../res/images";
import {
  PagingRequest,
  notifyResponse,
  addEditNotifyRequest,
  PagingRequestKT
} from "../../shared/models/notify-manger.model";
import Pagination from "react-js-pagination";
import notifyService from "../../shared/services/notify.service";
import documentService from "../../shared/services/document.service";
import fileDownload from 'js-file-download';
var ReactUltimatePagination = require('react-ultimate-pagination');

function Page(props: any) {
  return (
    <button
      className={`btn_page ${props.isActive ? "btn_page_active" : ""}`}
      style={{ fontWeight: props.isActive ? 'bold' : '200' }}
      onClick={props.onClick}
      disabled={props.disabled}
    >{props.value}</button>
  );
}
function Ellipsis(props: any) {
  return <button className="btn_page" onClick={props.onClick} disabled={props.disabled}>...</button>
}

function FirstPageLink(props: any) {
  return <button className="btn_page" onClick={props.onClick} disabled={props.disabled}>{"<<"}</button>
}

function PreviousPageLink(props: any) {
  return <button className="btn_page" onClick={props.onClick} disabled={props.disabled}>{"<"}</button>
}

function NextPageLink(props: any) {
  return <button className="btn_page" onClick={props.onClick} disabled={props.disabled}>{">"}</button>
}

function LastPageLink(props: any) {
  return <button className="btn_page" onClick={props.onClick} disabled={props.disabled}>{">>"}</button>
}

function Wrapper(props: any) {
  return <div className="pagination">{props.children}</div>
}

var itemTypeToComponent = {
  'PAGE': Page,
  'ELLIPSIS': Ellipsis,
  'FIRST_PAGE_LINK': FirstPageLink,
  'PREVIOUS_PAGE_LINK': PreviousPageLink,
  'NEXT_PAGE_LINK': NextPageLink,
  'LAST_PAGE_LINK': LastPageLink
};

var UltimatePagination = ReactUltimatePagination.createUltimatePagination({
  itemTypeToComponent: itemTypeToComponent,
  WrapperComponent: Wrapper
});

interface IState {
  dataTable?: Array<notifyResponse>;
  currentPage?: any;
  currentPageKT?: any;
  currentPageKD?: any;
  currentPageFile?: any;
  pagingRequest: PagingRequest;
  PagingRequestKT: PagingRequestKT;
  PagingRequestKD?: any;
  PagingRequestFile?: any;
  totalRecord?: any;
  totalRecordKT?: any;
  totalRecordKD?: any;
  totalRecordFile?: any;
  popup: any;
  titlePopup?: any;
  addEditNotifyRequest?: addEditNotifyRequest;
  validateDes?: boolean;
  loading?: boolean;
  dataAllLinkKT?: any;
  dataAllLinkKD?: any;
  dataAllFile?: any;
  totalPageKT?: any;
  totalPageKD?: any;
  totalPageFile?: any;
}
interface IProps {
  history?: any;
}



class PortalScreen extends React.Component<IProps, IState> {
  state: IState = {
    currentPage: 0,
    currentPageKT: 1,
    currentPageKD: 1,
    currentPageFile: 1,
    pagingRequest: {
      page: PAGE_SETTING.PAGE,
      pageSize: 50
    },
    PagingRequestKT: {
      page: PAGE_SETTING.PAGE,
      pageSize: PAGE_SETTING.PAGESIZE
    },
    PagingRequestKD: {
      page: PAGE_SETTING.PAGE,
      pageSize: PAGE_SETTING.PAGESIZE
    },
    PagingRequestFile: {
      page: PAGE_SETTING.PAGE,
      pageSize: PAGE_SETTING.PAGESIZE
    },
    totalRecord: 0,
    totalRecordKT: 0,
    popup: "",
    titlePopup: "",
    addEditNotifyRequest: {
      id: 0,
      des: ""
    },
    dataTable: [],
    validateDes: false,
    loading: false,
    dataAllLinkKT: [],
    dataAllLinkKD: [],
    dataAllFile: [],
    totalPageKT: 1,
    totalPageKD: 1,
    totalPageFile: 1
  };

  showLoading() {
    this.setState({ loading: true });
  }
  hideLoading() {
    this.setState({ loading: false });
  }

  componentDidMount() {
    this.fetchDataNotify(this.state.pagingRequest);
    this.fetchDataLinkKT();
    this.fetchDataLinkKD();
    this.fetchDataFile();
  }

  fetchDataNotify = (data: PagingRequest) => {
    this.showLoading();
    notifyService
      .getAll(data)
      .then(res => {
        this.hideLoading();
        if (res.data.code === RESPONSE_CODE.SUCCESS) {
          let arrayTable: Array<notifyResponse> = [];
          if (res.data.data.notifications.length > 0) {
            res.data.data.notifications.forEach(
              (element: notifyResponse, index: number) => {
                let obj: notifyResponse = {
                  index:
                    this.state.pagingRequest.page !== undefined &&
                      this.state.pagingRequest.pageSize !== undefined
                      ? this.state.pagingRequest.page *
                      this.state.pagingRequest.pageSize +
                      index +
                      1
                      : index + 1,
                  id: element.id,
                  des: element.des
                };
                arrayTable.push(obj);
              }
            );
          }
          let totalRecord;
          if (data.pageSize !== undefined) {
            totalRecord = data.pageSize * res.data.data.totalPage;
          }
          this.setState({
            dataTable: arrayTable,
            totalRecord: totalRecord
          });
        }
      })
      .catch(error => {
        message.error(ERROR_CONNECT);
        this.hideLoading();
      });
  };

  fetchDataLinkKT = () => {
    let data = {
      ...this.state.PagingRequestKT,
      "typeUrl": 0
    }
    this.showLoading();
    documentService
      .getDataByTypeUrl(data)
      .then(res => {
        this.hideLoading();
        if (res.data.code === RESPONSE_CODE.SUCCESS) {
          let arrayTable: Array<any> = [];
          if (res.data.data.documents.length > 0) {
            res.data.data.documents.forEach(
              (element: any, index: number) => {
                let obj: any = {
                  index:
                    this.state.PagingRequestKT.page !== undefined &&
                      this.state.PagingRequestKT.pageSize !== undefined
                      ? this.state.PagingRequestKT.page *
                      this.state.PagingRequestKT.pageSize +
                      index +
                      1
                      : index + 1,
                  id: element.id,
                  name: element.name,
                  status: element.status,
                  type: element.type,
                  typeUrl: element.typeUrl,
                  urlPath: element.urlPath,
                };
                arrayTable.push(obj);
              }
            );
          }
          let totalRecordKT;
          if (data.pageSize !== undefined) {
            totalRecordKT = data.pageSize * res.data.data.totalPage;
          }
          this.setState({
            dataAllLinkKT: arrayTable,
            totalRecordKT: totalRecordKT,
            totalPageKT: res.data.data.totalPage
          });
        }
      })
      .catch(error => {
        message.error(ERROR_CONNECT);
        this.hideLoading();
      });
  };

  fetchDataLinkKD = () => {
    let data = {
      ...this.state.PagingRequestKD,
      "typeUrl": 1
    }
    this.showLoading();
    documentService
      .getDataByTypeUrl(data)
      .then(res => {
        this.hideLoading();
        if (res.data.code === RESPONSE_CODE.SUCCESS) {
          let arrayTable: Array<any> = [];
          if (res.data.data.documents.length > 0) {
            res.data.data.documents.forEach(
              (element: any, index: number) => {
                let obj: any = {
                  index:
                    this.state.PagingRequestKD.page !== undefined &&
                      this.state.PagingRequestKD.pageSize !== undefined
                      ? this.state.PagingRequestKD.page *
                      this.state.PagingRequestKD.pageSize +
                      index +
                      1
                      : index + 1,
                  id: element.id,
                  name: element.name,
                  status: element.status,
                  type: element.type,
                  typeUrl: element.typeUrl,
                  urlPath: element.urlPath,
                };
                arrayTable.push(obj);
              }
            );
          }
          let totalRecordKD;
          if (data.pageSize !== undefined) {
            totalRecordKD = data.pageSize * res.data.data.totalPage;
          }
          this.setState({
            dataAllLinkKD: arrayTable,
            totalRecordKD: totalRecordKD,
            totalPageKD: res.data.data.totalPage
          });
        }
      })
      .catch(error => {
        message.error(ERROR_CONNECT);
        this.hideLoading();
      });
  };


  fetchDataFile = () => {
    let data = {
      ...this.state.PagingRequestFile,
      "typeUrl": -1
    }
    this.showLoading();
    documentService
      .getDataByTypeUrl(data)
      .then(res => {
        this.hideLoading();
        if (res.data.code === RESPONSE_CODE.SUCCESS) {
          let arrayTable: Array<any> = [];
          if (res.data.data.documents.length > 0) {
            res.data.data.documents.forEach(
              (element: any, index: number) => {
                let obj: any = {
                  index:
                    this.state.PagingRequestFile.page !== undefined &&
                      this.state.PagingRequestFile.pageSize !== undefined
                      ? this.state.PagingRequestFile.page *
                      this.state.PagingRequestFile.pageSize +
                      index +
                      1
                      : index + 1,
                  id: element.id,
                  name: element.name,
                  status: element.status,
                  type: element.type,
                  typeUrl: element.typeUrl,
                  urlPath: element.urlPath,
                };
                arrayTable.push(obj);
              }
            );
          }
          let totalRecordFile;
          if (data.pageSize !== undefined) {
            totalRecordFile = data.pageSize * res.data.data.totalPage;
          }
          this.setState({
            dataAllFile: arrayTable,
            totalRecordFile: totalRecordFile,
            totalPageFile: res.data.data.totalPage
          });
        }
      })
      .catch(error => {
        message.error(ERROR_CONNECT);
        this.hideLoading();
      });
  };


  handlePageChangeKT(pageNumber: any) {
    const obj = this.state.PagingRequestKT;
    obj.page = pageNumber - 1;
    this.setState(
      {
        PagingRequestKT: obj,
        currentPageKT: pageNumber
      },
      async () => {
        this.fetchDataLinkKT();
      }
    );
  }

  handlePageChangeKD(pageNumber: any) {
    const obj = this.state.PagingRequestKD;
    obj.page = pageNumber - 1;
    this.setState(
      {
        PagingRequestKD: obj,
        currentPageKD: pageNumber
      },
      async () => {
        this.fetchDataLinkKD();
      }
    );
  }

  handlePageChangeFile(pageNumber: any) {
    const obj = this.state.PagingRequestFile;
    obj.page = pageNumber - 1;
    this.setState(
      {
        PagingRequestFile: obj,
        currentPageFile: pageNumber
      },
      async () => {
        this.fetchDataFile();
      }
    );
  }

  onDowload = (name: any) => {
    let obj = {
      "fileName": name
    }
    documentService
      .getFile(obj)
      .then(res => {
        // if (res.data.code === RESPONSE_CODE.SUCCESS) {
        fileDownload(res.data, name);
        // }
      })
      .catch(error => {
        message.error(ERROR_CONNECT);
      });
  }


  render() {
    const { addEditNotifyRequest, dataTable, dataAllLinkKT, dataAllLinkKD, dataAllFile } = this.state;

    return (
      <>
        <div className="containerContent">
          <Spin spinning={this.state.loading} size="large">
            <Row
              style={{
                padding: '15px'
              }}
            >
              <Col span={24}>
                <div className="wrapper_notify">
                  <div className="container_title_khoi">
                    <div className="wrapper_title_khoi">
                      <img src={images.ic_notify_main} alt="" className="ic_notify_main" />
                      <div className="div_title_page">
                        <span className="titlePage">Thông báo</span>
                      </div>
                    </div>
                  </div>

                  <div className="listNotify">
                    {dataTable?.map((item: any) => {
                      return (
                        <Row className="row_item_list">
                          <span>
                            <img src={images.ic_arrow_right_red} alt="" className="ic_arrow_right" />
                            <a className="link item_des_client">{item.des}</a>
                          </span>
                        </Row>
                      );
                    })}
                  </div>
                </div>
              </Col>
            </Row>
            <Row
              style={{
                // marginTop: "10px"
              }}
            >
              <Col
                xs={24} xl={8}
                style={{
                  // paddingLeft: '10px',
                  // paddingRight: '10px',
                  // marginTop: "15px"
                }}
                className="col_padding_nd_left"
              >
                <div className="containerTable">
                  <Row>
                    <Col span={24} className="col_link">
                      <div className="div_padding_container_title">
                        <div className="container_title_khoi">
                          <div className="wrapper_title_khoi">
                            <img src={images.ic_link_kd} alt="" className="ic_notify_main" />
                            <div className="div_title_page">
                              <span className="titlePage">Hệ thống kinh doanh</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="list_init_kt">
                        {dataAllLinkKD?.map((item: any) => {
                          return (
                            <Row className="row_item_list">
                              <span>
                                <img src={images.ic_arrow_right_red} alt="" className="ic_arrow_right" />
                                <a className="link" href={item.urlPath} target="_blank">{item.name}</a>
                              </span>
                            </Row>
                          );
                        })}
                      </div>

                      <div className="wrapper_pagination">
                        <UltimatePagination
                          totalPages={this.state.totalPageKD == 0 ? 1 : this.state.totalPageKD}
                          currentPage={this.state.currentPageKD}
                          onChange={this.handlePageChangeKD.bind(this)}
                          siblingPagesRange={0}
                          boundaryPagesRange={0}
                        />
                      </div>
                    </Col>
                  </Row>
                </div>
              </Col>

              <Col
                xs={24} xl={8}
                style={{
                  // paddingLeft: '10px'
                  // marginTop: "15px"
                }}
                className="col_padding_nd_center"
              >
                <div className="containerTable">
                  <Row>
                    <Col span={24} className="col_link">
                      {/* <div className="title_link">
                        <span>Hệ thống kinh doanh</span>
                      </div> */}
                      <div className="div_padding_container_title">
                        <div className="container_title_khoi">
                          <div className="wrapper_title_khoi">
                            <img src={images.ic_link_kt} alt="" className="ic_notify_main" />
                            <div className="div_title_page">
                              <span className="titlePage">Hệ thống kĩ thuật</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="list_init_kt">
                        {dataAllLinkKT?.map((item: any) => {
                          return (
                            <Row className="row_item_list">
                              <span>
                                <img src={images.ic_arrow_right_red} alt="" className="ic_arrow_right" />
                                <a className="link" href={item.urlPath} target="_blank">{item.name}</a>
                              </span>
                            </Row>
                          );
                        })}
                      </div>

                      <div className="wrapper_pagination">
                        <UltimatePagination
                          totalPages={this.state.totalPageKT == 0 ? 1 : this.state.totalPageKT}
                          currentPage={this.state.currentPageKT}
                          onChange={this.handlePageChangeKT.bind(this)}
                          siblingPagesRange={0}
                          boundaryPagesRange={0}
                        />
                      </div>
                    </Col>
                  </Row>
                </div>
              </Col>

              <Col
                xs={24} xl={8}
                style={{
                  // paddingLeft: '10px'
                  // marginTop: "15px"
                }}
                className="col_padding_nd_right"
              >
                <div className="containerTable">
                  <Row>
                    <Col span={24} className="col_link">
                      <div className="div_padding_container_title">
                        <div className="container_title_khoi">
                          <div className="wrapper_title_khoi">
                            <img src={images.ic_document_dowload} alt="" className="ic_notify_main" />
                            <div className="div_title_page">
                              <span className="titlePage">Tài liệu</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="list_init_kt">
                        {dataAllFile?.map((item: any) => {
                          return (
                            <Row
                              className="row_item_list row_item_list_dowload"
                              onClick={(name: any) => this.onDowload(item.urlPath)}
                            >
                              <Col span={18}>
                                <Row>
                                  <span>
                                    <img src={images.ic_arrow_right_red} alt="" className="ic_arrow_right" />
                                    <a className="link">{item.name}</a>
                                  </span>
                                </Row>
                              </Col>
                              <Col span={6}>
                                <Row className="row_ic_dowload">
                                  <img src={item.status == VALUE_STATUS.NEW ? images.ic_new_1 : images.ic_fire_1} alt="" className="ic_status" />
                                  <img src={images.ic_dowload} alt="" className="ic_dowload" />
                                </Row>
                              </Col>
                            </Row>
                          );
                        })}
                      </div>

                      <div className="wrapper_pagination">
                        <UltimatePagination
                          totalPages={this.state.totalPageFile == 0 ? 1 : this.state.totalPageFile}
                          currentPage={this.state.currentPageFile}
                          onChange={this.handlePageChangeFile.bind(this)}
                          siblingPagesRange={0}
                          boundaryPagesRange={0}
                        />
                      </div>
                    </Col>
                  </Row>
                </div>
              </Col>
            </Row>

          </Spin>
        </div>
      </>
    );
  }
}

export default PortalScreen;
