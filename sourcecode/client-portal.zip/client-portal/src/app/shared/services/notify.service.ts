import ApiService from "./api.service";
class notifyService {
  getAll(data: object) {
    return ApiService.post("getAllNoti", data);
  }
}
export default new notifyService();
