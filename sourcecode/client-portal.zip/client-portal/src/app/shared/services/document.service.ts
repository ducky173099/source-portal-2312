import ApiService from "./api.service";
class documentService {
  getAll(data: object) {
    return ApiService.post("getAllDocument", data);
  }

  getDataByTypeUrl(data: any) {
    return ApiService.post("getDocumentByTypeUrl", data);
  }

  getFile(data: any) {
    return ApiService.post("getFile", data, { responseType: "blob" });
  }
}
export default new documentService();
