import React from "react";
import PortalScreen from "../views/portal/PortalScreen";

const RouterConfig = [
  {
    path: "/",
    component: PortalScreen
  },
  {
    path: "/portal",
    component: PortalScreen
  }
];
export default RouterConfig;
