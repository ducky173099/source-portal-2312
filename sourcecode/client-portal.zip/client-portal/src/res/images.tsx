/**
  * @author AW
  * @flow
  */
  
  const images = {
      favicon: require('../assets/images/favicon.png'),
    ic_arrow_right: require('../assets/images/ic_arrow_right.png'),
    ic_arrow_right_red: require('../assets/images/ic_arrow_right_red.png'),
    ic_delete: require('../assets/images/ic_delete.png'),
    ic_doc_main: require('../assets/images/ic_doc_main.png'),
    ic_document: require('../assets/images/ic_document.png'),
    ic_document_dowload: require('../assets/images/ic_document_dowload.png'),
    ic_dowload: require('../assets/images/ic_dowload.png'),
    ic_down: require('../assets/images/ic_down.png'),
    ic_edit: require('../assets/images/ic_edit.png'),
    ic_fire_1: require('../assets/images/ic_fire 1.png'),
    ic_link_kd: require('../assets/images/ic_link_kd.png'),
    ic_link_kt: require('../assets/images/ic_link_kt.png'),
    ic_menu: require('../assets/images/ic_menu.png'),
    ic_new_1: require('../assets/images/ic_new 1.png'),
    ic_notify_active: require('../assets/images/ic_notify_active.png'),
    ic_notify_main: require('../assets/images/ic_notify_main.png'),
    ic_user: require('../assets/images/ic_user.png'),
    logo: require('../assets/images/logo.png'),
    logo3: require('../assets/images/logo3.png'),
  }
  export default images