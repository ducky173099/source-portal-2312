import React from "react";
import { BrowserRouter } from "react-router-dom";
import "./App.css";
// import 'antd/dist/antd.min.css';
import { INFO_LOCALSTORAGE } from "./app/shared/constants/constant";
import AppLayout from "./app/views/layout/AppLayout";

function App() {

  return (
    <BrowserRouter>
      <AppLayout></AppLayout>
    </BrowserRouter>
  )
}

export default App;
