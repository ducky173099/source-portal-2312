const API_URL = {
  // API: "http://103.147.34.77:8087/api/"
  API: "http://10.240.192.92:8087/api/"
};

export default API_URL;
