import ApiService from "./api.service";
class documentService {
  getAll(data: any) {
    return ApiService.post("getAllDocument", data);
  }

  addEdit(data: any) {
    return ApiService.post("addEditDocument", data);
  }

  delete(data: any) {
    return ApiService.post("deleteDocument", data);
  }

  uploadDocument(data: any) {
    return ApiService.post("uploadDocument", data);
  }
}
export default new documentService();
