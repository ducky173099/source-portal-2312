import ApiService from "./api.service";
class notifyService {
  getAll(data: any) {
    return ApiService.post("getAllNoti", data);
  }

  addEditNotify(data: any) {
    return ApiService.post("addEditNoti", data);
  }

  delete(data: any) {
    return ApiService.post("deleteNoti", data);
  }
}
export default new notifyService();
