export interface PagingRequest {
  page?: number;
  pageSize?: number;
}
export interface dataAll {
  id?: any;
  des?: any;
}
export interface notifyResponse extends dataAll {
  index?: number;
}
export interface addEditNotifyRequest {
  id?: number;
  des?: any;
}
