export interface loginRequest {
    name?: any;
    pass?: any;
}