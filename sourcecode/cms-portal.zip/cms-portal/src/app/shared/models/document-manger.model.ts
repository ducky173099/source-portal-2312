export interface PagingRequest {
  page?: number;
  pageSize?: number;
}
export interface dataAll {
  id?: any;
  name?: any;
  type?: any;
  status?: any;
  urlPath?: any;
  typeUrl?: any;
  // urltype?:any
}
export interface documentResponse extends dataAll {
  index?: number;
}
export interface addEditDocumentRequest {
  id?: number;
  name?: any;
  type?: any;
  status?: any;
  urlPath?: any;
  urlType?: any;
}

export interface validateDoc {
  name?: any;
  type?: any;
  status?: any;
  urlPath?: any;
  urlType?: any;
}
