import React from "react";
import { Input, InputProps } from "antd";
import "./InputComponent.css";

interface IBaseState {
  // value?: string
}

interface IBaseProps extends InputProps {
  placeholder?: string;
  onChange?: any;
  className?: any;
  text?: string;
  error?: any;
  classStyle?: any;
  label?: any;
  isRequire?: any;
  containerStyle?: any;
  labelStyle?: any;
}

export default class InputComponent extends React.Component<
  IBaseProps,
  IBaseState
> {
  state: IBaseState = {};

  render() {
    const {
      className,
      text,
      classStyle,
      label,
      isRequire,
      containerStyle,
      labelStyle
    } = this.props;
    return (
      <>
        <div
          className="container_input"
          style={containerStyle ? containerStyle : null}
        >
          {label ? (
            isRequire ? (
              <>
                <span className="label_input" style={labelStyle}>
                  {label ? label : ""}
                </span>
                <span className="isRequire">*</span>
              </>
            ) : (
              <span className="label_input" style={labelStyle}>
                {label ? label : ""}
              </span>
            )
          ) : (
            <></>
          )}
          <Input
            {...this.props}
            //@ts-ignore
            maxLength={255}
            allowClear={true}
            style={this.props.style}
            className={`input_component ${className}`}
            placeholder={this.props.placeholder}
            size="middle"
            value={text ?? ""}
            onChange={e => {
              this.props.onChange(e.target.value);
            }}
          />
        </div>
      </>
    );
  }
}
