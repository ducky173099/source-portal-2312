import { Col, Modal, Row, Select, Button, Radio, Form, Input } from "antd";
import React from "react";
import ButtonComponent from "../button/ButtonComponent";
import "./ModalComponent.css";
import images from "../../../../res/images";
import {
  TYPE_POPUP,
  REQUIRE_VALIDATE
} from "../../constants/constant";
export const validNumber = new RegExp(/^[0-9]+$/);
interface IState {}

interface IProps {
  typePopup?: any;
  titlePopup?: any;
  visible?: any;
  onChangeAddEditDesc?: any;
  handleCancel?: () => void;
  handleAddEditNotify?: any;
  addEditDeleteRequest?: any;
  handleDelete?: any;
  validateDes?: any;
}

export default class ModalComponent extends React.PureComponent<
  IProps,
  IState
> {
  state: IState = {};

  render() {
    const {
      typePopup,
      titlePopup,
      visible,
      onChangeAddEditDesc,
      handleCancel,
      handleAddEditNotify,
      addEditDeleteRequest,
      handleDelete,
      validateDes
    } = this.props;

    return (
      <Modal
        centered={true}
        width={
          typePopup == TYPE_POPUP.POPUP_DELETE_NOTIFY ||
          typePopup == TYPE_POPUP.POPUP_DELETE_DOCUMENT
            ? "520px"
            : "650px"
        }
        title={titlePopup}
        visible={visible}
        onCancel={handleCancel}
        footer={null}
        className="modal_component"
        // closeIcon={<img src={images.ic_close_modal} />}
      >
        {typePopup == TYPE_POPUP.POPUP_DELETE_NOTIFY ||
        typePopup == TYPE_POPUP.POPUP_DELETE_DOCUMENT ? (
          <>
            <div
              style={{
                paddingLeft: "20px",
                paddingRight: "20px"
              }}
            >
              <Row>
                <Col
                  span={24}
                  className="name_delete"
                  style={{ marginTop: "0px" }}
                >
                  <span className="descDelete">
                    {" "}
                    Bạn có muốn xóa thông báo{" "}
                    <span className="modal_name_delete">
                      {addEditDeleteRequest?.des
                        ? addEditDeleteRequest?.des
                        : addEditDeleteRequest?.name}
                    </span>{" "}
                    không?
                  </span>
                </Col>
              </Row>
            </div>
            <Row className="modal_btn">
              <Col span={6}>
                <ButtonComponent
                  onClick={handleCancel}
                  title="Hủy bỏ"
                  style={{
                    backgroundColor: "#121212"
                  }}
                />
              </Col>
              <Col span={2} />
              <Col span={6}>
                <ButtonComponent title={"Xóa"} onClick={handleDelete} />
              </Col>
            </Row>
          </>
        ) : (
          <Form
            name="basic"
            initialValues={{ remember: true }}
            onFinish={handleAddEditNotify}
            autoComplete="off"
          >
            <div className="wrapper_body_role">
              <div className="ttkh_item">
                <span className="title_Item">
                  Tiêu đề thông báo <span className="star_red">*</span>
                </span>
                <Form.Item name="des" valuePropName={addEditDeleteRequest?.des}>
                    <Input.TextArea
                    maxLength={255}
                    allowClear
                    onChange={onChangeAddEditDesc}
                    value={addEditDeleteRequest?.des}
                    className={`text_area ${validateDes ? "errValid" : ""}`}
                    rows={5}
                    autoFocus={true}
                    placeholder="Nhập nội dung thông báo..."
                  />
                  {validateDes ? (
                    <span className="txt_err_validate">
                      {REQUIRE_VALIDATE.REQUIRE}
                    </span>
                  ) : (
                    <></>
                  )}
                </Form.Item>
              </div>
            </div>
            <Row className="modal_btn">
            <Col xs={10} md={8} xl={6}>
                <ButtonComponent
                  onClick={handleCancel}
                  title="Hủy bỏ"
                  style={{
                    backgroundColor: "#121212"
                  }}
                />
              </Col>
              <Col span={2} />
              <Col xs={10} md={8} xl={6}>
                <ButtonComponent
                  title={
                    typePopup == TYPE_POPUP.POPUP_ADD_NOTIFY
                      ? "Thêm mới"
                      : typePopup == TYPE_POPUP.POPUP_EDIT_NOTIFY
                      ? "Cập nhật"
                      : ""
                  }
                  htmlType="submit"
                />
              </Col>
            </Row>
          </Form>
        )}
      </Modal>
    );
  }
}
