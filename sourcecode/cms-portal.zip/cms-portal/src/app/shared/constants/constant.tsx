// export const ERROR_MESSAGE_500 = "Error! An error occurred. Please try again later";
export const ERROR_MESSAGE_500 = "Đã xảy ra lỗi. Vui lòng thử lại sau.";
// export const ERROR_MESSAGE_401 = "Login session expired. Please login again";
export const ERROR_MESSAGE_401 =
  "Phiên đăng nhập đã hết hạn. Xin vui lòng đăng nhập lại";
// export const ERROR_CONNECT = "Can not connect to server";
export const ERROR_CONNECT = "Không thể kết nối tới máy chủ";
export const INFO_LOCALSTORAGE = {
  USER_LOGGED: "userInfoCMS",
  TOKEN: "tokenCMS",
};
export const ERROR_CODE = {
  ERROR_500: 500,
  ERROR_401: 401,
  ERROR_403: 403,
};
export const RESPONSE_CODE = {
  SUCCESS: 0,
  ERROR: 1,
};
export const HEIGHT_TBODY = "50vh";
export const PAGE_SETTING = {
  PAGE: 0,
  PAGESIZE: 10,
  LIMITPAGE: 5
};

export const TYPE_POPUP = {
  POPUP_ADD_NOTIFY: "POPUP_ADD_NOTIFY",
  POPUP_EDIT_NOTIFY: "POPUP_EDIT_NOTIFY",
  POPUP_DELETE_NOTIFY: "POPUP_DELETE_NOTIFY",
  POPUP_DELETE_DOCUMENT: "POPUP_DELETE_DOCUMENT",
};

export const TITLE_POPUP = {
  POPUP_ADD_NOTIFY: "Thêm mới thông báo",
  POPUP_EDIT_NOTIFY: "Cập nhật thông báo",
  POPUP_DELETE_NOTIFY: "Xóa thông báo",
  POPUP_DELETE_DOCUMENT: "Xóa tài liệu",
};

export const REQUIRE_VALIDATE = {
  REQUIRE: "Bắt buộc.",
  REQUIRE_NUM: "Yêu cầu nhập số.",
  MAX_10: "Tối đa 10 ký tự.",
  MAX_11: "Tối đa 11 ký tự.",
  MAX_100: "Tối đa 100 ký tự.",
  MAX_200: "Tối đa 200 ký tự.",
  MAX_400: "Tối đa 400 ký tự.",
};

export const VALUE_TYPE = {
  LINK: 0,
  FILE: 1,
};

export const VALUE_STATUS = {
  NEW: 0,
  HOT: 1,
};

export const VALUE_SYSTEM = {
  KT: 0,
  KD: 1,
};

export const NAME_TYPE = {
  LINK: "Link",
  FILE: "File",
};

export const NAME_STATUS = {
  NEW: "New",
  HOT: "Hot",
};

export const NAME_SYSTEM = {
  KT: "Hệ thống kĩ thuật",
  KD: "Hệ thống kinh doanh",
};