import {
  Col,
  Dropdown,
  Layout,
  Menu,
  Row,
} from "antd";
import React, { Suspense, useEffect, useState } from "react";
import { Link, Redirect, Route, Switch, useLocation } from "react-router-dom";
import { LockOutlined } from "@ant-design/icons";
// import "antd/dist/antd.css";
import "antd/dist/antd.min.css";
import "./AppLayout.css";
import { INFO_LOCALSTORAGE } from "../../shared/constants/constant";
import RouterConfig from "../../routers/RouterConfig";
import images from "./../../../res/images";

const { Header, Sider, Content, Footer } = Layout;
const { SubMenu } = Menu;

function AppLayout() {
  const [collapsed, setCollapsed] = useState(false);
  const [fullName, setFullName] = useState("");
  const [activeMenu, setActiveMenu] = useState(
    window.location.href.split("/")[3]
  );
  const location = useLocation();
  const { pathname } = location;
  const pathnames = pathname.split("/").filter(item => item);
  const capatilize = (s: any) => s.charAt(0).toUpperCase() + s.slice(1);

  const currentLocation = window.location.href.split("/")[3];

  useEffect(() => {
    const obj = localStorage.getItem(INFO_LOCALSTORAGE.USER_LOGGED) || "";
    let parseObj = JSON.parse(obj);
    setFullName(parseObj.username);
  }, []);

  const toggle = () => {
    setCollapsed(!collapsed);
  };

  const logout = () => {
    localStorage.clear();
    window.location.href = "/login";
  };

  const menu = (
    <Menu>
      <Menu.Item icon={<LockOutlined />} onClick={logout}>
        <a>Đăng xuất</a>
      </Menu.Item>
    </Menu>
  );

  // console.log(object)

  return (
    <>
      <Layout>
        <Sider
          trigger={null}
          collapsible
          collapsed={collapsed}
          className="sidebar"
        >
          <div className="wrapper_logo">
            <div className="logo" />
          </div>
          <Menu mode="inline" defaultSelectedKeys={[activeMenu]}>
            <Menu.Item
              key="notify"
              icon={
                <img src={images.ic_notify_active} className="ic_item_menu" />
              }
              className={
                currentLocation == "notify" || currentLocation == ""
                  ? "select_itemenu"
                  : ""
              }
            >
              <Link to="/notify">Quản lý thông báo</Link>
            </Menu.Item>
            <Menu.Item
              key="document"
              icon={<img src={images.ic_document} className="ic_item_menu" />}
              className={currentLocation == "document" ? "select_itemenu" : ""}
            >
              <Link to="/document">Quản lý tài liệu</Link>
            </Menu.Item>
          </Menu>
        </Sider>

        <Layout>
          <Layout className="site-layout layout_content">
            <Header className="site-layout-background headerBar">
              <Row gutter={[24, 24]} className="full_height">
                <Col xs={18} xl={18} className="h_left">
                  <Row gutter={[24, 6]} className="">
                    <Col xs={24} xl={24}>
                      <span className="title_header">
                        Hệ thống công nghệ thông tin VTS
                      </span>
                    </Col>
                  </Row>
                </Col>
                <Col xs={6} xl={6} className="h_right">
                  <div className="wrapper_user">
                    <div className="wrapper_ava">
                      <img className="h_ava" src={images.ic_user} />
                    </div>
                    <Dropdown overlay={menu} placement="bottomLeft" arrow>
                      <div className="div_name">
                        <span className="txt_hello">{fullName}</span>
                        <img className="ic_down" src={images.ic_down} />
                      </div>
                    </Dropdown>
                  </div>
                </Col>
              </Row>
            </Header>
            <Content
              className="site-layout-background"
              style={{
                margin: "24px 16px",
                padding: 24,
                minHeight: 280
              }}
            >
              <Suspense fallback={<h1>Loading...</h1>}>
                <Switch>
                  {RouterConfig.map((route: any, i: any) => {
                    return (
                      <Route
                        key={i}
                        exact
                        path={route.path}
                        component={route.component}
                      />
                    );
                  })}
                </Switch>
              </Suspense>
            </Content>
          </Layout>
        </Layout>
      </Layout>
    </>
  );
}

export default AppLayout;
