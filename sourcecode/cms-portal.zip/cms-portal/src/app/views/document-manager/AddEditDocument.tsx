import { Col, Form, Input, message, Row, Spin, Select, Button } from "antd";
import React from "react";
import {
  ERROR_CONNECT,
  INFO_LOCALSTORAGE,
  RESPONSE_CODE,
  ERROR_CODE,
  REQUIRE_VALIDATE,
  VALUE_STATUS,
  VALUE_TYPE,
  NAME_STATUS,
  NAME_TYPE,
  VALUE_SYSTEM,
  NAME_SYSTEM
} from "../../shared/constants/constant";
import "./DocumentManager.css";
import images from "./../../../res/images";
import AuthService from "../../shared/services/login.service";
import InputComponent from "../../shared/components/input/InputComponent";
import ButtonComponent from "../../shared/components/button/ButtonComponent";
import moment from "moment";
import {
  PagingRequest,
  documentResponse,
  addEditDocumentRequest,
  validateDoc

} from "../../shared/models/document-manger.model";
import documentService from "../../shared/services/document.service";

interface IState {
  addEditDocumentRequest?: addEditDocumentRequest;
  validImport?: boolean;
  fileName?: any;
  validateDoc?:validateDoc
  loading?: boolean
  fileUpload?: any;
  validateFile?:any
}
interface IProps {
  location?: any;
  history?:any
}

const { Option } = Select;

class AddEditDocument extends React.Component<IProps, IState> {
  upload: any;
  constructor(props: IProps) {
    super(props);
    this.state = {
      addEditDocumentRequest: {
        id: 0,
        name: "",
        type: 0,
        status: null,
        urlPath: "",
        urlType: VALUE_SYSTEM.KT
      },
      validImport: false,
      fileName: null,
      validateDoc: {
        name: false,
        type: false,
        status: false,
        urlPath: false,
        urlType: false
      },
      loading: false,
      fileUpload: null,
      validateFile: false
    };
    this.upload = React.createRef();
  }

  showLoading() {
    this.setState({ loading: true });
  }
  hideLoading() {
    this.setState({ loading: false });
  }

  componentDidMount() {
    if (this.props.location.state != undefined) {
      const getParams = this.props.location.state.params;
      if (getParams != null) {
        this.mapDataEdit(getParams)
      }
    }
   }

  mapDataEdit = (getParams:any) => {
    let request: any = this.state.addEditDocumentRequest;
    request["id"] = getParams.id;
    request["name"] = getParams.name;
    request["type"] = getParams.type;
    request["status"] = getParams.status;
    request["urlPath"] = getParams.urlPath
    request["urlType"] = getParams.typeUrl
    
    this.setState({
      addEditDocumentRequest: request,
      fileUpload: -1
    })
  }

  onFinish = async (values: any) => {
    const { addEditDocumentRequest, fileUpload } = this.state;
    if (addEditDocumentRequest?.urlPath == "" && addEditDocumentRequest?.type == VALUE_TYPE.FILE) {
      this.setState({
        validImport: true
      })
      return;
    }
    if (addEditDocumentRequest?.type == VALUE_TYPE.FILE) {
      if (fileUpload == -1) {
        let objAddEdit = {
          id: addEditDocumentRequest?.id,
          name: addEditDocumentRequest?.name,
          type: addEditDocumentRequest?.type,
          status: addEditDocumentRequest?.status,
          urlPath: addEditDocumentRequest?.urlPath,
          urlType: addEditDocumentRequest?.type == 1 ? -1 : addEditDocumentRequest?.urlType
        }
        await this.fetchAddEditDocument(objAddEdit);
      } else {
        await this.uploadFile();
      }
    } else {
      let objAddEdit = {
        id: addEditDocumentRequest?.id,
        name: addEditDocumentRequest?.name,
        type: addEditDocumentRequest?.type,
        status: addEditDocumentRequest?.status,
        urlPath: addEditDocumentRequest?.urlPath,
        urlType: addEditDocumentRequest?.type == 1 ? -1 : addEditDocumentRequest?.urlType
      }
      await this.fetchAddEditDocument(objAddEdit);
    }
    
  };

  fetchAddEditDocument = (data: any) => {
    documentService
      .addEdit(data)
      .then(res => {
        this.hideLoading();
        if (res.data.code === RESPONSE_CODE.SUCCESS) {
          message.success("Save success");
          window.location.replace("/document");
        } else {
          message.error(res.data.msg);
        }
      })
      .catch(error => {
        message.error("Error! An error occurred. Please try again later ");
        this.hideLoading();
      });
  }

  uploadFile = () => {
    const { fileUpload } = this.state;
    if (fileUpload === undefined || fileUpload === null) {
      this.setState({
        validImport: true,
      });
      return;
    }
    let formData = new FormData();
    formData.append("file", fileUpload);
    documentService
      .uploadDocument(formData)
      .then(res => {
        if (res.data.code === RESPONSE_CODE.SUCCESS) {
          // message.success("Upload file thành công")
          let request: any = this.state.addEditDocumentRequest;
          request["urlPath"] = res.data.data.fileName;
          this.setState({
            addEditDocumentRequest: request,
            validateFile: false
          }, () => {
            this.onAddEdit()
          });
        } else { 
          message.error(res.data.msg)
        }
      })
      .catch(error => {
        message.error("Error! An error occurred. Please try again later ");
      });
  }

  onAddEdit = async () => {
    const { addEditDocumentRequest } = this.state;

    let objAddEdit = {
      id: addEditDocumentRequest?.id,
      name: addEditDocumentRequest?.name,
      type: addEditDocumentRequest?.type,
      status: addEditDocumentRequest?.status,
      urlPath: addEditDocumentRequest?.urlPath,
      urlType: addEditDocumentRequest?.type == 1 ? -1 : addEditDocumentRequest?.urlType
    }
    await this.fetchAddEditDocument(objAddEdit);
  }

  onChangeTitle = (text: any) => {
    let request: any = this.state.addEditDocumentRequest;
    request["name"] = text;
    this.setState({
      addEditDocumentRequest: request,
    });
  };

  onChangeTypeUpload = (event: any) => {
    let request: any = this.state.addEditDocumentRequest;
    request["type"] = event;
    this.setState({
      addEditDocumentRequest: request,
    });
  };

  onChangeStatus = (event: any) => {
    let request: any = this.state.addEditDocumentRequest;
    request["status"] = event;
    this.setState({
      addEditDocumentRequest: request,
    });
  };

  onChangeFile = (text: any) => {
    let request: any = this.state.addEditDocumentRequest;
    request["urlPath"] = text;
    this.setState({
      addEditDocumentRequest: request,
    });
  };

  onChangeUrltype = (event: any) => {
    let request: any = this.state.addEditDocumentRequest;
    request["urlType"] = event;
    this.setState({
      addEditDocumentRequest: request,
    });
  };

  handleSelectFile = (event: any) => {
    let fileName = event.target.files[0].name;
    let file = event.target.files[0];
    let request: any = this.state.addEditDocumentRequest;
    // request["urlPath"] = file;
    request["urlPath"] = fileName;

    if (
      // file.type ==
      //   "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
      // file.type ==
      //   "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
      file.type !== "" || file.type != undefined
    ) {
      this.setState({
        addEditDocumentRequest: request,
        validImport: false,
        fileName: fileName,
        fileUpload: file
      });
    } else {
      this.setState({
        validImport: true,
      });
    }
  };

  render() {
    const { addEditDocumentRequest, fileName } = this.state;
    const getParams = this.props.location.state.params;
    return (
      <div className="containerContent addEditDocument">
        <Row>
          <Col span={24}>
            {
              getParams != null ?
              <h2>Cập nhật tài liệu</h2>
                :
              <h2>Thêm mới tài liệu</h2>
            }
          </Col>
        </Row>

        <Form
          name="basic"
            initialValues={{
              remember: true,
            }}
          className="form_addedit"
          onFinish={this.onFinish}
        >
          <Row>
            <Col span={24}>
              <Form.Item
                name="name"
                rules={
                  addEditDocumentRequest?.name && addEditDocumentRequest?.name.trim().length > 0? []
                    : addEditDocumentRequest?.name.trim().length == 0 ? [
                        {
                        required: true,
                        message: REQUIRE_VALIDATE.REQUIRE,
                        whitespace: true
                      }
                    ]
                      :
                    [
                      {
                        required: true,
                        message: REQUIRE_VALIDATE.REQUIRE,
                        whitespace: true
                      }
                    ]
                }
                valuePropName={addEditDocumentRequest?.name}
              >
                <InputComponent
                  label="Tiêu đề"
                  isRequire={true}
                  labelStyle={{
                    color: "#000",
                  }}
                  placeholder="Nhập tiêu đề tài liệu"
                  text={addEditDocumentRequest?.name}
                  onChange={(text: any) => {
                    this.onChangeTitle(text);
                  }}
                />
              </Form.Item>
            </Col>
          </Row>
          <Row>
            <Col span={10}>
              <div className="ttkh_item">
                <span className="titleitem">
                  Loại upload <span className="star_red">*</span>
                </span>
                <Form.Item
                  name="type"
                  rules={
                    addEditDocumentRequest?.type == VALUE_TYPE.LINK || addEditDocumentRequest?.type == VALUE_TYPE.FILE
                      ? []
                      : [
                          {
                            required: true,
                            message: REQUIRE_VALIDATE.REQUIRE,
                          },
                        ]
                  }
                  valuePropName={addEditDocumentRequest?.type}
                >
                  <Select
                    allowClear
                    className="select_option"
                    size="middle"
                    showSearch
                    placeholder="---Chọn---"
                    optionFilterProp="children"
                    onChange={this.onChangeTypeUpload}
                    value={addEditDocumentRequest?.type}
                    //   suffixIcon={<img src={images.ic_down} />}
                  >
                    <Option value={VALUE_TYPE.LINK}>{NAME_TYPE.LINK}</Option>
                    <Option value={VALUE_TYPE.FILE}>{NAME_TYPE.FILE}</Option>
                  </Select>
                </Form.Item>
              </div>
            </Col>
            <Col span={4} />
            {
              addEditDocumentRequest?.type == VALUE_TYPE.LINK ?
              <Col span={10}>
                <div className="ttkh_item">
                  <span className="titleitem">
                    Khối hệ thống <span className="star_red">*</span>
                  </span>
                  <Form.Item
                    name="urlType"
                    rules={
                      addEditDocumentRequest?.urlType == VALUE_SYSTEM.KT ||
                      addEditDocumentRequest?.urlType == VALUE_SYSTEM.KD ? []
                      :
                      [{
                        required: true,
                        message: REQUIRE_VALIDATE.REQUIRE,
                      }]
                    }
                    valuePropName={addEditDocumentRequest.urlType}
                  >
                    <Select
                      allowClear
                      className="select_option"
                      size="middle"
                      showSearch
                      placeholder="---Chọn---"
                      optionFilterProp="children"
                      onChange={this.onChangeUrltype}
                      value={addEditDocumentRequest?.urlType}
                      //   suffixIcon={<img src={images.ic_down} />}
                      >
                      <Option value={VALUE_SYSTEM.KT}>{NAME_SYSTEM.KT}</Option>
                      <Option value={VALUE_SYSTEM.KD}>{NAME_SYSTEM.KD}</Option>
                    </Select>
                  </Form.Item>
                </div>
              </Col>
                :
              <Col span={10}>
                <div className="ttkh_item">
                  <span className="titleitem">
                    Trạng thái <span className="star_red">*</span>
                  </span>
                  <Form.Item
                    name="status"
                    rules={
                      addEditDocumentRequest?.status == VALUE_STATUS.NEW ||
                      addEditDocumentRequest?.status == VALUE_STATUS.HOT ? []
                      :
                      [{
                        required: true,
                        message: REQUIRE_VALIDATE.REQUIRE,
                      }]
                    }
                    valuePropName={addEditDocumentRequest?.status}
                  >
                    <Select
                      allowClear
                      className="select_option"
                      size="middle"
                      showSearch
                      placeholder="---Chọn---"
                      optionFilterProp="children"
                      onChange={this.onChangeStatus}
                      value={addEditDocumentRequest?.status}
                      //   suffixIcon={<img src={images.ic_down} />}
                    >
                      <Option value={VALUE_STATUS.NEW}>{NAME_STATUS.NEW}</Option>
                      <Option value={VALUE_STATUS.HOT}>{NAME_STATUS.HOT}</Option>
                    </Select>
                  </Form.Item>
                </div>
              </Col>
            }
            
          </Row>
          <Row>
            {addEditDocumentRequest?.type == VALUE_TYPE.LINK ? (
              <Col span={24}>
                <Form.Item
                  name="urlPath"
                  rules={
                    addEditDocumentRequest?.urlPath && addEditDocumentRequest?.urlPath.trim().length > 0 ? []
                    :
                    [{
                      required: true,
                      message: REQUIRE_VALIDATE.REQUIRE,
                      whitespace: true
                      }]
                  }
                  valuePropName={addEditDocumentRequest?.urlPath}
                >
                  <InputComponent
                    label="Link upload"
                    isRequire={true}
                    labelStyle={{
                      color: "#000",
                    }}
                    placeholder="Nhập link"
                    text={addEditDocumentRequest?.urlPath}
                    onChange={(text: any) => {
                      this.onChangeFile(text);
                    }}
                  />
                </Form.Item>
              </Col>
            ) : (
              <>
                <Col xs={10} xl={4}>
                  <div className="ttkh_item">
                    <span className="titleitem">
                      Upload file <span className="star_red">*</span>
                    </span>
                    <input
                      ref={(ref) => (this.upload = ref)}
                      onChange={this.handleSelectFile}
                      type="file"
                      style={{ display: "none" }}
                    />
                    <div className="flex_import">
                      {
                        addEditDocumentRequest?.urlPath != "" || getParams != null ? (
                          <img
                            src={images.ic_doc_main}
                            style={{
                              width: "50px",
                              height: "50px",
                            }}
                          />
                      ) : (
                        <Button
                          onClick={() => {
                            this.upload.value = "";
                            this.upload.click();
                          }}
                          className="btnImport"
                        >
                          <span>Browse</span>
                        </Button>
                      )}

                        <span>{
                            addEditDocumentRequest?.urlPath != null ? addEditDocumentRequest?.urlPath
                              : ""
                        }</span>
                        {
                          this.state.validImport ?
                            <span className="error_file">Chọn file.</span>
                            :
                            <></>
                        }
                    </div>
                    {getParams != null || addEditDocumentRequest?.urlPath != "" ? (
                      <Button
                        onClick={() => {
                          this.upload.value = "";
                          this.upload.click();
                        }}
                        className="btnImport"
                      >
                        <span>Update file</span>
                      </Button>
                    ) : (
                      <></>
                    )}
                  </div>
                </Col>
              </>
            )}
          </Row>
          <div style={{ textAlign: "center", marginTop: "35px" }}>
            <Row
              style={{
                justifyContent: 'center'
              }}
            >
              <Col xs={10} xl={8} md={6} >
                <ButtonComponent
                  onClick={() => this.props.history.push({pathname: `/document`})}
                  title={"Hủy bỏ"}
                  btnStyle={"cancelBtn"}
                  titleStyle={{
                    fontWeight: "700",
                  }}
                />
              </Col>
              <Col xs={2} xl={1}/>
              <Col xs={10} xl={8} md={6} >
                <ButtonComponent
                  htmlType="submit"
                  title={getParams == null ? "Thêm mới" : "Cập nhật"}
                  titleStyle={{
                    fontWeight: "700",
                  }}
                />
              </Col>
            </Row>
          </div>
        </Form>
      </div>
    );
  }
}

export default AddEditDocument;
