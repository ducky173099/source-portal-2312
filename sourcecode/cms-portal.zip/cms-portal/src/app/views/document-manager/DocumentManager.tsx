import React from "react";
import {
  ERROR_CONNECT,
  INFO_LOCALSTORAGE,
  RESPONSE_CODE,
  ERROR_CODE,
  HEIGHT_TBODY,
  PAGE_SETTING,
  TYPE_POPUP,
  TITLE_POPUP,
  VALUE_STATUS,
  VALUE_TYPE,
  NAME_STATUS,
  NAME_TYPE
} from "../../shared/constants/constant";
import {
  Col,
  message,
  Row,
  Spin,
  Table,
  Button,
  Empty,
} from "antd";
import "./DocumentManager.css";
import images from "../../../res/images";
import ButtonComponent from "../../shared/components/button/ButtonComponent";
import ModalComponent from "../../shared/components/modal/ModalComponent";
import {
  PagingRequest,
  documentResponse,
  addEditDocumentRequest,
} from "../../shared/models/document-manger.model";
import Pagination from "react-js-pagination";
import documentService from "../../shared/services/document.service";
var ReactUltimatePagination = require('react-ultimate-pagination');

function Page(props:any) {
  return (
    <button
      className={`btn_page ${props.isActive ? "btn_page_active" : ""}`}
      style={{fontWeight: props.isActive ? 'bold' : '200'}}
      onClick={props.onClick}
      disabled={props.disabled}
    >{props.value}</button>
  );
}
function Ellipsis(props:any) {
  return <button className="btn_page" onClick={props.onClick} disabled={props.disabled}>...</button>
}

function FirstPageLink(props:any) {
  return <button className="btn_page" onClick={props.onClick} disabled={props.disabled}>{"<<"}</button>
}

function PreviousPageLink(props:any) {
  return <button className="btn_page" onClick={props.onClick} disabled={props.disabled}>{"<"}</button>
}

function NextPageLink(props:any) {
  return <button className="btn_page" onClick={props.onClick} disabled={props.disabled}>{">"}</button>
}

function LastPageLink(props:any) {
  return <button className="btn_page" onClick={props.onClick} disabled={props.disabled}>{">>"}</button>
}

function Wrapper(props:any) {
  return <div className="pagination">{props.children}</div>
}

var itemTypeToComponent = {
  'PAGE': Page,
  'ELLIPSIS': Ellipsis,
  'FIRST_PAGE_LINK': FirstPageLink,
  'PREVIOUS_PAGE_LINK': PreviousPageLink,
  'NEXT_PAGE_LINK': NextPageLink,
  'LAST_PAGE_LINK': LastPageLink
};

var UltimatePagination = ReactUltimatePagination.createUltimatePagination({
  itemTypeToComponent: itemTypeToComponent,
  WrapperComponent: Wrapper
});


interface IState {
  dataTable?: any;
  currentPage?: any;
  pagingRequest: PagingRequest;
  totalRecord?: any;
  popup: any;
  titlePopup?: any;
  visibleModal?: boolean;
  addEditDocumentRequest?: addEditDocumentRequest;
  loading?: boolean;
  totalPage?:any
}
interface IProps {
  history?: any;
}

class DocumentManager extends React.Component<IProps, IState> {
  state: IState = {
    currentPage: 1,
    pagingRequest: {
      page: PAGE_SETTING.PAGE,
      pageSize: PAGE_SETTING.PAGESIZE,
    },
    totalRecord: 0,
    popup: "",
    titlePopup: "",
    visibleModal: false,
    addEditDocumentRequest: {
      id: 0,
      name: "",
      type: '',
      status: '',
      urlPath: null,
      urlType: null
    },
    dataTable: [],
    loading: false,
    totalPage: 1
  };


  showLoading() {
    this.setState({ loading: true });
  }
  hideLoading() {
    this.setState({ loading: false });
  }

  componentDidMount() {
    this.fetchAllDocument(this.state.pagingRequest);
  }

  fetchAllDocument = (data: PagingRequest) => {
    this.showLoading();
    documentService
    .getAll(data)
    .then(res => {
      this.hideLoading();
      if (res.data.code === RESPONSE_CODE.SUCCESS) {
        let arrayTable: Array<documentResponse> = [];
        if (res.data.data.documents.length > 0) {
          res.data.data.documents.forEach(
            (element: documentResponse, index: number) => {
              let obj: documentResponse = {
                index:
                  this.state.pagingRequest.page !== undefined &&
                  this.state.pagingRequest.pageSize !== undefined
                    ? this.state.pagingRequest.page *
                        this.state.pagingRequest.pageSize +
                      index +
                      1
                    : index + 1,
                id: element.id,
                name: element.name,
                type: element.type,
                status: element.status,
                urlPath: element.urlPath,
                typeUrl: element.typeUrl
              };
              arrayTable.push(obj);
            }
          );
        }
        let totalRecord;
        if (data.pageSize !== undefined) {
          totalRecord = data.pageSize * res.data.data.totalPage;
        }
        this.setState({
          dataTable: arrayTable,
          totalRecord: totalRecord,
          totalPage: res.data.data.totalPage
        });
      }
    })
    .catch(error => {
      message.error("Error! An error occurred. Please try again later ");
      this.hideLoading();
    });
  }

  handlePageChange(pageNumber: any) {
    const obj = this.state.pagingRequest;
    obj.page = pageNumber - 1;
    this.setState(
      {
        pagingRequest: obj,
        // currentPage: pageNumber - 1,
        currentPage: pageNumber,
      },
      async () => {
        this.fetchAllDocument(this.state.pagingRequest);
      }
    );
  }

  onPress(type: string) {
    switch (type) {
      case TYPE_POPUP.POPUP_DELETE_DOCUMENT:
        this.setState({
          popup: TYPE_POPUP.POPUP_DELETE_DOCUMENT,
          titlePopup: TITLE_POPUP.POPUP_DELETE_DOCUMENT,
          visibleModal: true,
        });
        break;
      default:
        break;
    }
  }

  handleCancel = () => {
    this.setState({ visibleModal: !this.state.visibleModal });
  };

  onAdd = () => {
    this.props.history.push({
      pathname: "/document/add-document",
      state: { params: null },
    });
  };

  onEdit = (record: any) => {
    this.props.history.push({
      // pathname: `/document/${record.record.index}`,
      pathname: `/document/edit-document`,
      state: { params: record.record },
    });
  };

  showModalDelete = (record: any) => {
    var request: any = this.state.addEditDocumentRequest;
    request["id"] = record.record.id;
    request["name"] = record.record.name;
    request["type"] = record.record.type;
    request["status"] = record.record.status;
    request["urlPath"] = record.record.urlPath;
    request["urlType"] = record.record.typeUrl;
    this.setState({
      addEditDocumentRequest: request,
    });
    this.onPress(TYPE_POPUP.POPUP_DELETE_DOCUMENT);
  };

  handleDelete = () => {
    const {addEditDocumentRequest} = this.state;
    var idDelete = {
      "id": addEditDocumentRequest?.id,
    }
    this.showLoading();

    documentService.delete(idDelete).then(res => {
      this.hideLoading();
      if (res.data.code === RESPONSE_CODE.SUCCESS) {
        message.success("Delete success");
        this.setState({
          visibleModal: !this.state.visibleModal
        }, () => {
          this.fetchAllDocument(this.state.pagingRequest);
        });
      }
    }).catch(err => { 
      message.error("Error! An error occurred. Please try again later ");
      this.hideLoading();
    });
  }

  onChangeAddEditDesc = (event: any) => {
    var request: any = this.state.addEditDocumentRequest;
    request["desc"] = event.target.value;
    this.setState({
      addEditDocumentRequest: request,
    });
  };

  columns = [
    {
      title: "STT",
      dataIndex: "index",
      align: "center" as "center",
      sorter: (a: any, b: any) => a.index - b.index,
      width: "15%",
    },
    {
      title: "Tiêu đề",
      dataIndex: "name",
      align: "center" as "center",
      width: "40%",
    },
    {
      title: "Loại upload",
      dataIndex: "type",
      align: "center" as "center",
      width: "15%",
      render: (type: any) =>
      type == VALUE_TYPE.LINK
        ? NAME_TYPE.LINK
        : NAME_TYPE.FILE,
    },
    {
      title: "Trạng thái",
      dataIndex: "status",
      align: "center" as "center",
      width: "15%",
      render: (type: any) =>
      type == VALUE_STATUS.NEW
        ? NAME_STATUS.NEW
        : NAME_STATUS.HOT,
    },
    {
      title: "Hành động",
      dataIndex: "action",
      key: "action",
      width: "15%",
      align: "center" as "center",
      render: (text: any, record: any) => (
        <>
          <Button
            size="small"
            type="link"
            className=""
            onClick={() => this.onEdit({ record })}
          >
            <img
              alt=""
              width="32px"
              height="32px"
              className="ic_table"
              src={images.ic_edit}
            />
          </Button>
          <Button
            size="small"
            type="link"
            className=""
            onClick={() => this.showModalDelete({ record })}
          >
            <img
              alt=""
              width="32px"
              height="32px"
              className="ic_table"
              src={images.ic_delete}
            />
          </Button>
        </>
      ),
    },
  ];

  render() {
    const { addEditDocumentRequest } = this.state;
    return (
      <>
        <ModalComponent
          typePopup={this.state.popup}
          titlePopup={this.state.titlePopup}
          visible={this.state.visibleModal}
          addEditDeleteRequest={addEditDocumentRequest}
          handleDelete={this.handleDelete}
          handleCancel={this.handleCancel}
        />
        <div className="containerContent">
          <Spin spinning={this.state.loading} size="large">
            <Row>
              <Col span={24}>
                <h2 className="titlePage">Danh sách tài liệu</h2>
              </Col>
            </Row>
            <Row
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginBottom: "20px",
              }}
            >
              <div />
              <Col xs={10} md={6} xl={4} >
                <ButtonComponent title="Thêm mới" onClick={this.onAdd} />
              </Col>
            </Row>
            <Row>
              <Col span={24}>
                <div className="containerTable">
                  <Table
                    columns={this.columns}
                    dataSource={this.state.dataTable}
                    scroll={{
                      y: HEIGHT_TBODY,
                      scrollToFirstRowOnChange: true,
                    }}
                    locale={{
                      emptyText: <Empty description={"Không có dữ liệu"} />,
                    }}
                    bordered
                    pagination={false}
                    onRow={(record, index) => {
                      return {
                        onClick: (event) => {}, // click row
                        onDoubleClick: (event) => {}, // double click row
                        onContextMenu: (event) => {}, // right button click row
                        onMouseEnter: (event) => {}, // mouse enter row
                        onMouseLeave: (event) => {}, // mouse leave row
                      };
                    }}
                  />
                  <div className="wrapper_pagination">
                    <UltimatePagination
                      totalPages={this.state.totalPage == 0 ? 1 : this.state.totalPage}
                      currentPage={this.state.currentPage}
                        onChange={this.handlePageChange.bind(this)}
                        siblingPagesRange={0}
                    />
                  </div>
                </div>
              </Col>
            </Row>
          </Spin>
        </div>
      </>
    );
  }
}

export default DocumentManager;
