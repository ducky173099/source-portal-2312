import { Col, Form, Input, message, Row, Spin } from "antd";
import React from "react";
import {
  ERROR_CONNECT,
  INFO_LOCALSTORAGE,
  RESPONSE_CODE,
  ERROR_CODE
} from "../../shared/constants/constant";
import "antd/dist/antd.min.css";
import "./LoginScreen.css";
import images from "./../../../res/images";
import AuthService from "../../shared/services/login.service";
import InputComponent from "../../shared/components/input/InputComponent";
import ButtonComponent from "../../shared/components/button/ButtonComponent";

interface ILoginState {
  loading: boolean;
  username?: string;
  password?: string;
}
interface ILoginProps { }


class LoginScreen extends React.Component<ILoginProps, ILoginState> {
  state: ILoginState = {
    loading: false,
    username: "",
    password: ""
  };

  componentDidMount() {
    localStorage.clear();
  }

  onFinish = (values: any) => {
    const data = {
      username: values.username,
      password: values.password
    };

    AuthService.signIn(data)
      .then(res => {
        if (res.data.code === RESPONSE_CODE.SUCCESS) {
          this.setState({ loading: true });

          localStorage.setItem(
            INFO_LOCALSTORAGE.TOKEN,
            res.data.data.accessToken
          );
          localStorage.setItem(
            INFO_LOCALSTORAGE.USER_LOGGED,
            JSON.stringify(res.data.data.userDto)
          );
          window.location.href = "/notify";
        } else {
          message.error(res.data.msg);
        }
      })
      .catch(function (error) {
        message.error({ key: "error3", content: ERROR_CONNECT });
      });
  };

  onChangeUsername = (text: any) => {
    this.setState({ username: text });
  };

  onChangePassword = (text: any) => {
    this.setState({ password: text });
  };

  render() {
    const { } = this.state;
    return (
      <div className="container_login">
        <div className="wrapper_login">
          <p className="titleLogin">Login</p>
          <Form
            name="basic"
            initialValues={{
              remember: true
            }}
            onFinish={this.onFinish}
          >
            <Row className="row_login">
              <Col xs={12} xl={16}>
                <Form.Item
                  name="username"
                  className="mb_25"
                  rules={[
                    {
                      required: true,
                      message: "Nhập tên đăng nhập"
                    }
                  ]}
                >
                  <InputComponent
                    classStyle="input_width"
                    label="Tài khoản"
                    isRequire={true}
                    containerStyle={{
                      marginTop: 15
                    }}
                    placeholder="Nhập tên đăng nhập"
                    text={this.state.username}
                    onChange={(text: any) => {
                      this.onChangeUsername(text);
                    }}
                  />
                </Form.Item>
              </Col>
            </Row>

            <Row className="row_login">
              <Col xs={16} xl={16}>
                <Form.Item
                  name="password"
                  rules={[
                    {
                      required: true,
                      message: "Nhập mật khẩu"
                    }
                  ]}
                >
                  <InputComponent
                    type="password"
                    classStyle="input_width"
                    label="Mật khẩu"
                    isRequire={true}
                    containerStyle={{
                      marginTop: 15
                    }}
                    placeholder="Nhập mật khẩu"
                    text={this.state.password}
                    onChange={(text: any) => {
                      this.onChangePassword(text);
                    }}
                  />
                </Form.Item>
              </Col>
            </Row>
            <Row className="row_login">
              <Col xs={12} xl={8}>
                <div style={{ textAlign: "center", marginTop: "35px" }}>
                  <ButtonComponent
                    htmlType="submit"
                    title="Đăng nhập"
                    titleStyle={{
                      fontWeight: "700"
                    }}
                  />
                </div>
              </Col>
            </Row>
          </Form>
        </div>
      </div>
    );
  }
}

export default LoginScreen;
