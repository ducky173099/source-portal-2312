import React from "react";
import {
  ERROR_CONNECT,
  INFO_LOCALSTORAGE,
  RESPONSE_CODE,
  ERROR_CODE,
  HEIGHT_TBODY,
  PAGE_SETTING,
  TYPE_POPUP,
  TITLE_POPUP
} from "../../shared/constants/constant";
import {
  Col,
  Form,
  Input,
  message,
  Row,
  Spin,
  Table,
  Button,
  Empty,
} from "antd";
import "./NotifyManagerScreen.css";
import images from "./../../../res/images";
import InputComponent from "../../shared/components/input/InputComponent";
import ButtonComponent from "../../shared/components/button/ButtonComponent";
import ModalComponent from "./../../shared/components/modal/ModalComponent";
import {
  PagingRequest,
  notifyResponse,
  addEditNotifyRequest
} from "../../shared/models/notify-manger.model";
import Pagination from "react-js-pagination";
import notifyService from "../../shared/services/notify.service";
var ReactUltimatePagination = require('react-ultimate-pagination');

function Page(props: any) {
  return (
    <button
      className={`btn_page ${props.isActive ? "btn_page_active" : ""}`}
      style={{ fontWeight: props.isActive ? 'bold' : '200' }}
      onClick={props.onClick}
      disabled={props.disabled}
    >{props.value}</button>
  );
}
function Ellipsis(props: any) {
  return <button className="btn_page" onClick={props.onClick} disabled={props.disabled}>...</button>
}

function FirstPageLink(props: any) {
  return <button className="btn_page" onClick={props.onClick} disabled={props.disabled}>{"<<"}</button>
}

function PreviousPageLink(props: any) {
  return <button className="btn_page" onClick={props.onClick} disabled={props.disabled}>{"<"}</button>
}

function NextPageLink(props: any) {
  return <button className="btn_page" onClick={props.onClick} disabled={props.disabled}>{">"}</button>
}

function LastPageLink(props: any) {
  return <button className="btn_page" onClick={props.onClick} disabled={props.disabled}>{">>"}</button>
}

function Wrapper(props: any) {
  return <div className="pagination">{props.children}</div>
}

var itemTypeToComponent = {
  'PAGE': Page,
  'ELLIPSIS': Ellipsis,
  'FIRST_PAGE_LINK': FirstPageLink,
  'PREVIOUS_PAGE_LINK': PreviousPageLink,
  'NEXT_PAGE_LINK': NextPageLink,
  'LAST_PAGE_LINK': LastPageLink
};

var UltimatePagination = ReactUltimatePagination.createUltimatePagination({
  itemTypeToComponent: itemTypeToComponent,
  WrapperComponent: Wrapper
});

interface IState {
  dataTable?: Array<notifyResponse>;
  currentPage?: any;
  pagingRequest: PagingRequest;
  totalRecord?: any;
  popup: any;
  titlePopup?: any;
  visibleModal?: boolean;
  addEditNotifyRequest?: addEditNotifyRequest;
  validateDes?: boolean;
  loading?: boolean
  totalPage?: any
}
interface IProps {
  history?: any;
}

class NotifyManagerScreen extends React.Component<IProps, IState> {
  state: IState = {
    currentPage: 1,
    pagingRequest: {
      page: PAGE_SETTING.PAGE,
      pageSize: PAGE_SETTING.PAGESIZE
      // pageSize: 1
    },
    totalRecord: 0,
    popup: "",
    titlePopup: "",
    visibleModal: false,
    addEditNotifyRequest: {
      id: 0,
      des: ""
    },
    dataTable: [],
    validateDes: false,
    loading: false,
    totalPage: 1
  };

  showLoading() {
    this.setState({ loading: true });
  }
  hideLoading() {
    this.setState({ loading: false });
  }

  componentDidMount() {
    this.fetchDataNotify(this.state.pagingRequest);
  }

  fetchDataNotify = (data: PagingRequest) => {
    this.showLoading();
    notifyService
      .getAll(data)
      .then(res => {
        this.hideLoading();
        if (res.data.code === RESPONSE_CODE.SUCCESS) {
          // notifyResponse
          let arrayTable: Array<any> = [];
          if (res.data.data.notifications.length > 0) {
            res.data.data.notifications.forEach(
              (element: any, index: number) => {
                let obj: any = {
                  index:
                    this.state.pagingRequest.page !== undefined &&
                      this.state.pagingRequest.pageSize !== undefined
                      ? this.state.pagingRequest.page *
                      this.state.pagingRequest.pageSize +
                      index +
                      1
                      : index + 1,
                  id: element.id,
                  des: element.des,
                  key: element.id
                };
                arrayTable.push(obj);
              }
            );
          }
          let totalRecord;
          if (data.pageSize !== undefined) {
            totalRecord = data.pageSize * res.data.data.totalPage;
          }
          this.setState({
            dataTable: arrayTable,
            totalRecord: totalRecord,
            totalPage: res.data.data.totalPage
          });
        }
      })
      .catch(error => {
        message.error("Error! An error occurred. Please try again later ");
        this.hideLoading();
      });
  };

  handlePageChange(pageNumber: any) {
    const obj = this.state.pagingRequest;
    obj.page = pageNumber - 1;
    this.setState(
      {
        pagingRequest: obj,
        currentPage: pageNumber
      },
      async () => {
        this.fetchDataNotify(this.state.pagingRequest);
      }
    );
  }

  onPress(type: string) {
    switch (type) {
      case TYPE_POPUP.POPUP_ADD_NOTIFY:
        this.setState({
          popup: TYPE_POPUP.POPUP_ADD_NOTIFY,
          titlePopup: TITLE_POPUP.POPUP_ADD_NOTIFY,
          visibleModal: true
        });
        break;
      case TYPE_POPUP.POPUP_EDIT_NOTIFY:
        this.setState({
          popup: TYPE_POPUP.POPUP_EDIT_NOTIFY,
          titlePopup: TITLE_POPUP.POPUP_EDIT_NOTIFY,
          visibleModal: true
        });
        break;
      case TYPE_POPUP.POPUP_DELETE_NOTIFY:
        this.setState({
          popup: TYPE_POPUP.POPUP_DELETE_NOTIFY,
          titlePopup: TITLE_POPUP.POPUP_DELETE_NOTIFY,
          visibleModal: true
        });
        break;
      default:
        break;
    }
  }

  clearContent = () => {
    var request: any = this.state.addEditNotifyRequest;
    request["id"] = 0;
    request["des"] = "";

    this.setState({
      addEditNotifyRequest: request
    });
  };

  handleCancel = () => {
    this.clearContent();
    this.setState({
      visibleModal: !this.state.visibleModal,
      validateDes: false
    });
  };

  addEvent = () => {
    this.onPress(TYPE_POPUP.POPUP_ADD_NOTIFY);
  };

  onEdit = (record: any) => {
    this.onPress(TYPE_POPUP.POPUP_EDIT_NOTIFY);
    var request: any = this.state.addEditNotifyRequest;
    request["id"] = record.record.id;
    request["des"] = record.record.des;

    this.setState({
      addEditNotifyRequest: request
    });
  };

  showModalDelete = (record: any) => {
    var request: any = this.state.addEditNotifyRequest;
    request["id"] = record.record.id;
    request["des"] = record.record.des;
    this.setState({
      addEditNotifyRequest: request
    });
    this.onPress(TYPE_POPUP.POPUP_DELETE_NOTIFY);
  };

  validate = () => {
    const { addEditNotifyRequest } = this.state;
    if (
      addEditNotifyRequest?.des == '' ||
      addEditNotifyRequest?.des == null ||
      addEditNotifyRequest?.des == undefined ||
      addEditNotifyRequest?.des.trim().length == 0
    ) {
      return true;
    } else {
      return false;
    }

  }

  handleAddEditNotify = () => {
    const { addEditNotifyRequest } = this.state;
    if (this.validate()) {
      this.setState({
        validateDes: true
      })
    } else {
      this.setState({
        validateDes: false
      })
      const { addEditNotifyRequest } = this.state;
      let objAddEdit = {
        id: addEditNotifyRequest?.id,
        des: addEditNotifyRequest?.des
      };
      this.fetchAddEditNotify(objAddEdit);
    }
  };

  fetchAddEditNotify = (data: any) => {
    this.showLoading();
    notifyService
      .addEditNotify(data)
      .then(res => {
        if (res.data.code === RESPONSE_CODE.SUCCESS) {
          message.success("Save success");
          this.setState(
            {
              visibleModal: !this.state.visibleModal
            },
            () => {
              this.clearContent();
              this.fetchDataNotify(this.state.pagingRequest);
            }
          );
        } else {
          message.error(res.data.msg);
        }
      })
      .catch(error => {
        message.error("Error! An error occurred. Please try again later ");
        this.hideLoading();
      });
  };

  handleDelete = () => {
    const { addEditNotifyRequest } = this.state;
    var idDelete = {
      "id": addEditNotifyRequest?.id,
    }
    this.showLoading();
    notifyService.delete(idDelete).then(res => {
      this.hideLoading();
      if (res.data.code === RESPONSE_CODE.SUCCESS) {
        message.success("Delete success");
        this.setState({
          visibleModal: !this.state.visibleModal
        }, () => {
          this.fetchDataNotify(this.state.pagingRequest);
        });
      }
    }).catch(err => {
      message.error("Error! An error occurred. Please try again later ");
      this.hideLoading();
    });
  };

  onChangeAddEditDesc = (event: any) => {
    var request: any = this.state.addEditNotifyRequest;
    request["des"] = event.target.value;
    this.setState({
      addEditNotifyRequest: request,
      validateDes: false
    });
  };

  columns = [
    {
      title: "STT",
      dataIndex: "index",
      align: "center" as "center",
      sorter: (a: any, b: any) => a.index - b.index,
      width: "15%"
    },
    {
      title: "Nội dung thông báo",
      dataIndex: "des",
      align: "center" as "center",
      width: "65%"
    },
    {
      title: "Hành động",
      dataIndex: "action",
      key: "action",
      width: "20%",
      align: "center" as "center",
      render: (text: any, record: any) => (
        <>
          <Button
            size="small"
            type="link"
            className=""
            onClick={() => this.onEdit({ record })}
          >
            <img
              alt=""
              width="32px"
              height="32px"
              className="ic_table"
              src={images.ic_edit}
            />
          </Button>
          <Button
            size="small"
            type="link"
            className=""
            onClick={() => this.showModalDelete({ record })}
          >
            <img
              alt=""
              width="32px"
              height="32px"
              className="ic_table"
              src={images.ic_delete}
            />
          </Button>
        </>
      )
    }
  ];


  render() {
    const { addEditNotifyRequest } = this.state;

    return (
      <>
        <ModalComponent
          validateDes={this.state.validateDes}
          typePopup={this.state.popup}
          titlePopup={this.state.titlePopup}
          visible={this.state.visibleModal}
          addEditDeleteRequest={addEditNotifyRequest}
          onChangeAddEditDesc={(event: any) => this.onChangeAddEditDesc(event)}
          handleAddEditNotify={this.handleAddEditNotify}
          handleDelete={this.handleDelete}
          handleCancel={this.handleCancel}
        />
        <div className="containerContent">
          <Spin spinning={this.state.loading} size="large">
            <Row>
              <Col span={24}>
                <h2 className="titlePage">Danh sách thông báo</h2>
              </Col>
            </Row>
            <Row
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginBottom: "20px"
              }}
            >
              <div />
              <Col xs={10} md={6} xl={4} >
                <ButtonComponent title="Thêm mới" onClick={this.addEvent} />
              </Col>
            </Row>
            <Row>
              <Col span={24}>
                <div className="containerTable">
                  <Table
                    columns={this.columns}
                    dataSource={this.state.dataTable}
                    scroll={{
                      y: HEIGHT_TBODY,
                      scrollToFirstRowOnChange: true
                    }}
                    locale={{
                      emptyText: <Empty description={"Không có dữ liệu"} />
                    }}
                    bordered
                    pagination={false}
                    onRow={(record, index) => {
                      return {
                        onClick: event => { }, // click row
                        onDoubleClick: event => { }, // double click row
                        onContextMenu: event => { }, // right button click row
                        onMouseEnter: event => { }, // mouse enter row
                        onMouseLeave: event => { } // mouse leave row
                      };
                    }}
                  />
                  <div className="wrapper_pagination">
                    <UltimatePagination
                      totalPages={this.state.totalPage == 0 ? 1 : this.state.totalPage}
                      currentPage={this.state.currentPage}
                      onChange={this.handlePageChange.bind(this)}
                      siblingPagesRange={0}
                    />
                  </div>
                </div>
              </Col>
            </Row>
          </Spin>
        </div>
      </>
    );
  }
}

export default NotifyManagerScreen;
