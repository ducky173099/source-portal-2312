import React from "react";
import LoginScreen from "../views/login/LoginScreen";
import NotifyManagerScreen from "../views/notify-manager/NotifyManagerScreen";
import DocumentManager from "../views/document-manager/DocumentManager";
import AddEditDocument from "../views/document-manager/AddEditDocument";

const RouterConfig = [
  {
    path: "/",
    component: NotifyManagerScreen
  },
  {
    path: "/notify",
    component: NotifyManagerScreen
  },
  {
    path: "/document",
    component: DocumentManager
  },
  {
    path: "/document/add-document",
    component: AddEditDocument
  },
  {
    path: "/document/edit-document",
    component: AddEditDocument
  }
];
export default RouterConfig;
