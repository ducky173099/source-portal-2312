const colors = new class {
    _color_2d2c2c = "#2D2C2C";
    _color_black_main = '#121212';
}();
export default colors;